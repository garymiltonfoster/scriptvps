#!/bin/bash
#######################################################
# HocVPS Script v4.0.0 for CentOS 7
# To install type:
# curl -sO https://hocvps.com/install && bash install
# or
# curl -sO https://hocvps.com/scripts/$(rpm -E %centos)/install && bash install
#######################################################
server_name=abc.vn
ROOT_FOLDER="$(pwd)"
admin_password=xLNgd2VtwngsqT93
mariadb_root_password=xLNgd2VtwngsqT93
hocvps_version="4.0.0"
phpmyadmin_version="4.9.5" # Released 2020-03-21. Older version compatible with PHP 5.5 to 7.4 and MySQL 5.5 and newer. Currently supported for security fixes only.
extplorer_version="2.1.13" # 05/15/2019 04:43 PM
extplorer_id="82"
low_ram='262144' # 256MB
LINE="========================================================================="
print_message() {
    if [ "$1" == "" ]; then
        printf "$LINE\n"
    else
        printf "$LINE\n$1\n$LINEs\n"
    fi
}

clear
print_message "Hoan tat qua trinh cau hinh..."
# HocVPS Script Admin
/usr/bin/cp -rf $ROOT_FOLDER/package/administrator/* rm -rf /home/$server_name/private_html/
printf "admin:$(openssl passwd -apr1 $admin_password)\n" >/home/$server_name/private_html/hocvps/.htpasswd
sed -i "s/rootpassword/$mariadb_root_password/g" /home/$server_name/private_html/hocvps/SQLManager.php

# Server Info
mkdir /home/$server_name/private_html/serverinfo/
/usr/bin/cp -rf $ROOT_FOLDER/package/serverinfo.php /home/$server_name/private_html/serverinfo/index.php

# phpMyAdmin
mkdir /home/$server_name/private_html/phpmyadmin/
cd /home/$server_name/private_html/phpmyadmin/
wget --no-check-certificate -q https://files.phpmyadmin.net/phpMyAdmin/$phpmyadmin_version/phpMyAdmin-$phpmyadmin_version-all-languages.zip
unzip -q phpMyAdmin-$phpmyadmin_version-all-languages.zip
mv -f phpMyAdmin-$phpmyadmin_version-all-languages/* .
rm -rf phpMyAdmin-$phpmyadmin_version-all-languages*
mv config.sample.inc.php config.inc.php
blowfish_secret=$(head -c 32 /dev/random | base64)
sed -i "s/\['blowfish_secret'\] = ''/\['blowfish_secret'\] = '$blowfish_secret'/" config.inc.php
pmapass=$(head -c 32 /dev/random | base64)
mysql -e "CREATE USER 'pma'@'localhost' IDENTIFIED BY '$pmapass';" 2>/dev/null
mysql -e "GRANT SELECT, INSERT, UPDATE, DELETE ON phpmyadmin.* TO 'pma'@'localhost'  IDENTIFIED BY '$pmapass';;" 2>/dev/null
sed -i "s/\/\/ \$cfg\['Servers'\]\[\$i\]\['controluser'\] = 'pma'/\$cfg\['Servers'\]\[\$i\]\['controluser'\] = 'pma'/" config.inc.php
sed -i "s/\/\/ \$cfg\['Servers'\]\[\$i\]\['controlpass'\] = 'pmapass'/\$cfg\['Servers'\]\[\$i\]\['controlpass'\] = '$pmapass'/" config.inc.php

# eXtplorer File Manager
mkdir /home/$server_name/private_html/filemanager/
cd /home/$server_name/private_html/filemanager/
wget --no-check-certificate -q https://extplorer.net/attachments/download/$extplorer_id/eXtplorer_$extplorer_version.zip
unzip -q eXtplorer_$extplorer_version.zip && rm -f eXtplorer_$extplorer_version.zip
cat >"/home/$server_name/private_html/filemanager/config/.htusers.php" <<END
<?php
        if( !defined( '_JEXEC' ) && !defined( '_VALID_MOS' ) ) die( 'Restricted access' );
        \$GLOBALS["users"]=array(
        array('admin','$(echo -n "$admin_password" | md5sum | awk '{print $1}')','/home','http://localhost','1','','7',1),
);
?>
END

# Log Rotation
cat >"/etc/logrotate.d/nginx" <<END
/home/*/logs/access.log /home/*/logs/error.log /home/*/logs/nginx_error.log {
	create 640 nginx nginx
        daily
	dateext
        missingok
        rotate 5
        maxage 7
        compress
	size=100M
        notifempty
        sharedscripts
        postrotate
                [ -f /var/run/nginx.pid ] && kill -USR1 \`cat /var/run/nginx.pid\`
        endscript
	su nginx nginx
}
END
cat >"/etc/logrotate.d/php-fpm" <<END
/home/*/logs/php-fpm*.log {
        daily
	dateext
        compress
        maxage 7
        missingok
        notifempty
        sharedscripts
        size=100M
        postrotate
            /bin/kill -SIGUSR1 \`cat /var/run/php-fpm/php-fpm.pid 2>/dev/null\` 2>/dev/null || true
        endscript
	su nginx nginx
}
END
cat >"/etc/logrotate.d/mysql" <<END
/home/*/logs/mysql*.log {
        create 640 mysql mysql
        notifempty
        daily
        rotate 3
        maxage 7
        missingok
        compress
        postrotate
        # just if mysqld is really running
        if test -x /usr/bin/mysqladmin && \
           /usr/bin/mysqladmin ping &>/dev/null
        then
           /usr/bin/mysqladmin flush-logs
        fi
        endscript
	su mysql mysql
}
END

# Change port SSH
sed -i "s/#Port 22/Port $ssh_port/g" /etc/ssh/sshd_config

cat >"/etc/fail2ban/jail.local" <<END
[sshd]
enabled  = true
filter   = sshd
action   = iptables[name=SSH, port=$ssh_port, protocol=tcp]
logpath  = /var/log/secure
maxretry = 3
bantime = 3600

[nginx-http-auth]
enabled = true
filter = nginx-http-auth
action = iptables[name=NoAuthFailures, port=$admin_port, protocol=tcp]
logpath = /home/$server_name/logs/nginx_error.log
maxretry = 3
bantime = 3600
END

systemctl start fail2ban.service

# Open port
if [ -f /etc/sysconfig/iptables ]; then
    iptables -I INPUT -p tcp --dport 80 -j ACCEPT
    iptables -I INPUT -p tcp --dport 25 -j ACCEPT
    iptables -I INPUT -p tcp --dport 443 -j ACCEPT
    iptables -I INPUT -p tcp --dport 465 -j ACCEPT
    iptables -I INPUT -p tcp --dport 587 -j ACCEPT
    iptables -I INPUT -p tcp --dport $admin_port -j ACCEPT
    iptables -I INPUT -p tcp --dport $ssh_port -j ACCEPT
    service iptables save
fi

mkdir -p /var/lib/php/session
chown -R nginx:nginx /var/lib/php
chown nginx:nginx /home/$server_name
chown -R nginx:nginx /home/*/public_html
chown -R nginx:nginx /home/*/private_html

rm -f /root/install
echo -n "cd /home" >>/root/.bashrc

mkdir -p /etc/hocvps/

cat >"/etc/hocvps/scripts.conf" <<END
hocvps_version="$hocvps_version"
server_name="$server_name"
server_ip="$server_ip"
admin_port="$admin_port"
ssh_port="$ssh_port"
mariadb_root_password="$mariadb_root_password"
END
chmod 600 /etc/hocvps/scripts.conf

clear
print_message "Cau hinh hoan tat, bat dau them menu hocvps, nhanh thoi..."

>/bin/hocvps
cat $ROOT_FOLDER/hocvps/hocvps >/bin/hocvps && chmod +x /bin/hocvps
mkdir -p /etc/hocvps/menu/
/usr/bin/cp $ROOT_FOLDER/component/menu/* /etc/hocvps/menu
chmod +x /etc/hocvps/menu/*

clear
cat >"/root/hocvps-script.txt" <<END
=========================================================================
                        MANAGE VPS INFORMATION
=========================================================================
Lenh truy cap menu HocVPS Script: hocvps

Domain chinh: http://$server_name/ hoac http://$server_ip/

HocVPS Script Admin: http://$server_name:$admin_port/ hoac http://$server_ip:$admin_port/
File Manager:        http://$server_name:$admin_port/filemanager/ hoac http://$server_ip:$admin_port/filemanager/
phpMyAdmin:          http://$server_name:$admin_port/phpmyadmin/ hoac http://$server_ip:$admin_port/phpmyadmin/
Server Info:         http://$server_name:$admin_port/serverinfo/ hoac http://$server_ip:$admin_port/serverinfo/
PHP OPcache:         http://$server_name:$admin_port/op.php hoac http://$server_ip:$admin_port/op.php

Thong tin dang nhap mac dinh cho tat ca tool:
Username: admin
Password: $admin_password

Neu can ho tro, cac ban hay truy cap https://hocvps.com/script/
END

chmod 600 /root/hocvps-script.txt

if [ "$1" = "wordpress" ]; then
    print_message "Hoan tat qua trinh cai dat HocVPS Script + WordPress!"
    printf "Tiep theo ban hay truy cap http://$server_name \n hoac http://$server_ip de cau hinh WordPress \n"
else
    print_message "Scripts HocVPS da hoan tat qua trinh cai dat..."
    printf "Sau day la thong tin server moi cua ban, hay doc can than va luu giu lai\n"
    printf "de su dung sau nay:\n\n"
    print_message
    printf "Domain chinh: http://$server_name/ hoac http://$server_ip/\n"
fi

print_message
printf "HocVPS Script Admin: http://$server_name:$admin_port/ \n hoac http://$server_ip:$admin_port/\n\n"
printf "File Manager: http://$server_name:$admin_port/filemanager/ \n hoac http://$server_ip:$admin_port/filemanager/\n\n"
printf "phpMyAdmin: http://$server_name:$admin_port/phpmyadmin/ \n hoac http://$server_ip:$admin_port/phpmyadmin/\n\n"
printf "Server Info: http://$server_name:$admin_port/serverinfo/ \n hoac http://$server_ip:$admin_port/serverinfo/\n\n"
printf "PHP OPcache: http://$server_name:$admin_port/op.php \n hoac http://$server_ip:$admin_port/op.php\n"
print_message
printf "Thong tin dang nhap mac dinh cho tat ca tool:\n"
printf " Username: admin\n"
printf " Password: $admin_password\n"
print_message "Thong tin quan ly duoc luu tai: /root/hocvps-script.txt"
printf "***Luu y: Port dang nhap SSH da duoc doi tu 22 sang $ssh_port de bao mat VPS\n"
print_message
printf "De quan ly server, ban hay dung lenh \"hocvps\" khi ket noi SSH.\n"
printf "Neu can ho tro, cac ban hay truy cap https://hocvps.com/script/\n"
print_message
printf "Server se tu dong khoi dong lai sau 3s nua.... \n\n"
sleep 3
reboot
exit
