<?php
// Ensure the URL is dynamically built and secure
$protocol = (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off' || $_SERVER['SERVER_PORT'] == 443) ? "https://" : "http://";
$host = htmlspecialchars($_SERVER['HTTP_HOST'], ENT_QUOTES, 'UTF-8');
$admin_url = $protocol . $host;
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>HocVPS Script Admin</title>
    <link type="text/css" href="hocvps/css/screen.css" rel="stylesheet" media="all" />
    <style>
        /* Optional: Styling the button to match existing links */
        .button-link {
            display: inline-block;
            padding: 10px 20px;
            margin: 5px 0;
            background-color: #007BFF;
            color: #fff;
            text-decoration: none;
            border-radius: 4px;
        }

        .button-link:hover {
            background-color: #0056b3;
        }
    </style>
</head>
<body>

<h1>HocVPS Script Admin</h1>

<div id="main_content">
    <h2>Hello, admin</h2>
    
    <p>Thank you for using HocVPS Script!</p>
    
    <h3>Here are some tools to manage your server:</h3>
    
    <ul>
        <li>HocVPS Script Admin: <a href="<?php echo $admin_url; ?>/" target="_blank"><?php echo $admin_url; ?>/</a></li>
        <li>File Manager: <a href="<?php echo $admin_url; ?>/tinyfilemanager.php" target="_blank"><?php echo $admin_url; ?>/tinyfilemanager</a></li>
        <li>phpMyAdmin: <a href="<?php echo $admin_url; ?>/phpmyadmin/" target="_blank"><?php echo $admin_url; ?>/phpmyadmin/</a></li>
        <li>Server Info: <a href="<?php echo $admin_url; ?>/serverinfo/" target="_blank"><?php echo $admin_url; ?>/serverinfo/</a></li>
        <li>PHP OPcache Management: <a href="<?php echo $admin_url; ?>/op.php" target="_blank"><?php echo $admin_url; ?>/op.php</a></li>
        <!-- New Change Password Option -->
        <li>
            <a href="<?php echo $admin_url; ?>/index2.php?action=changePassword" target="_blank" class="button-link">
                Đổi Password Script
            </a>
        </li>
    </ul>
    
    <p>Default username is <strong>admin</strong> for all tools, and the password is auto-generated and stored in the file: <code>/root/hocvps-script.txt</code></p>
</div>

</body>
</html>
